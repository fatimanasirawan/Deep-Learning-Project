# app.py

import os
import numpy as np
from flask import Flask, request, render_template, redirect, url_for
from tensorflow.keras.preprocessing import image
import tensorflow as tf
from tensorflow.keras.losses import SparseCategoricalCrossentropy

app = Flask(__name__)

# Custom loss function class
class CustomSparseCategoricalCrossentropy(SparseCategoricalCrossentropy):
    @classmethod
    def from_config(cls, config):
        if 'fn' in config:
            config.pop('fn')
        return cls(**config)

# Custom load model function
def custom_load_model(filepath):
    return tf.keras.models.load_model(filepath, custom_objects={'SparseCategoricalCrossentropy': CustomSparseCategoricalCrossentropy})

model = custom_load_model('flowercategory.h5') # Replace with your model path

class_names = ['daisy', 'dandelion', 'roses', 'sunflowers', 'tulips']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    if file:
        # Save the uploaded image
        filepath = os.path.join('static', file.filename)
        file.save(filepath)
        
        # Preprocess the image
        img = image.load_img(filepath, target_size=(180, 180))
        img_array = image.img_to_array(img)
        img_array = tf.expand_dims(img_array, 0)  # Create a batch dimension
        
        # Make predictions
        predictions = model.predict(img_array)
        score = tf.nn.softmax(predictions[0])
        
        # Get the result
        predicted_class = class_names[np.argmax(score)]
        confidence = 100 * np.max(score)
        
        result = {
            "class": predicted_class,
            "confidence": confidence,
            "filename": file.filename  # Pass filename to result page
        }
        
        return render_template('result.html', result=result)

if __name__ == "__main__":
    app.run(debug=True)
